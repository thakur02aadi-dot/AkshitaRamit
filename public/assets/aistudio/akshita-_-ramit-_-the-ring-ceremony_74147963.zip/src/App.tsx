/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState } from 'react';
import { Navbar } from './components/Navbar';
import { InvitationEnvelope } from './components/InvitationEnvelope';
import { HeroSection } from './components/HeroSection';
import { CoupleSection } from './components/CoupleSection';
import { CountdownTimer } from './components/CountdownTimer';
import { EventDetails } from './components/EventDetails';
import { VenueSection } from './components/VenueSection';
import { RSVPSection } from './components/RSVPSection';
import { FooterSection } from './components/FooterSection';
import { FloatingPetals } from './components/FloatingPetals';
import { OriginalCardModal } from './components/OriginalCardModal';
import { weddingAudio } from './utils/audioPlayer';

export default function App() {
  const [isEnvelopeOpen, setIsEnvelopeOpen] = useState(false);
  const [isCardModalOpen, setIsCardModalOpen] = useState(false);
  const [isMusicPlaying, setIsMusicPlaying] = useState(false);

  const handleEnvelopeOpen = () => {
    setIsEnvelopeOpen(true);
  };

  const handleMusicStarted = () => {
    setIsMusicPlaying(true);
  };

  return (
    <div className="relative min-h-screen bg-[#FFFDF9] text-[#4A151B] selection:bg-[#B32638] selection:text-white font-sans-clean">
      {/* Falling Rose Petals and Golden Sparkles */}
      <FloatingPetals />

      {/* Cinematic Invitation Envelope Opening Screen */}
      {!isEnvelopeOpen && (
        <InvitationEnvelope
          onOpen={handleEnvelopeOpen}
          onMusicStarted={handleMusicStarted}
        />
      )}

      {/* Main Luxury Wedding Invitation Experience */}
      <div className={`transition-opacity duration-1000 ${isEnvelopeOpen ? 'opacity-100' : 'opacity-0'}`}>
        <Navbar
          onOpenCardModal={() => setIsCardModalOpen(true)}
          isMusicPlaying={isMusicPlaying}
          setIsMusicPlaying={setIsMusicPlaying}
        />

        <main>
          {/* SECTION 2: Hero Section */}
          <HeroSection onOpenCardModal={() => setIsCardModalOpen(true)} />

          {/* SECTION 3: Couple Introduction */}
          <CoupleSection />

          {/* SECTION 4: Live Dynamic Countdown Timer */}
          <CountdownTimer />

          {/* SECTION 5: Event Details & Itinerary */}
          <EventDetails />

          {/* SECTION 6: Venue & Directions */}
          <VenueSection />

          {/* SECTION 7: RSVP & Direct Family Contact */}
          <RSVPSection />
        </main>

        {/* SECTION 8: Emotional Closing & Footer */}
        <FooterSection onOpenCardModal={() => setIsCardModalOpen(true)} />

        {/* Original Invitation Card Lightbox Modal */}
        <OriginalCardModal
          isOpen={isCardModalOpen}
          onClose={() => setIsCardModalOpen(false)}
        />
      </div>
    </div>
  );
}
