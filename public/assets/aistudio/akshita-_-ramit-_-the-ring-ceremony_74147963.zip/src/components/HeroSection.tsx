import React from 'react';
import { motion } from 'motion/react';
import { GaneshaMotif, CornerFlourish, RoyalRings } from './Ornaments';
import { Calendar, MapPin, Sparkles, Heart } from 'lucide-react';

interface HeroSectionProps {
  onOpenCardModal: () => void;
}

export const HeroSection: React.FC<HeroSectionProps> = ({ onOpenCardModal }) => {
  return (
    <section
      id="hero"
      className="relative min-h-screen flex flex-col items-center justify-center pt-24 pb-16 px-4 sm:px-6 overflow-hidden bg-radial from-[#FFF5EC] via-[#FFFDF9] to-[#FBF2EA]"
    >
      {/* Background Ornate Corner Flourishes */}
      <div className="absolute inset-4 sm:inset-8 border border-[#ECC880]/30 rounded-3xl pointer-events-none">
        <CornerFlourish position="top-left" className="absolute top-0 left-0 w-20 sm:w-32 h-20 sm:h-32 text-[#D4AF37]/60" />
        <CornerFlourish position="top-right" className="absolute top-0 right-0 w-20 sm:w-32 h-20 sm:h-32 text-[#D4AF37]/60" />
        <CornerFlourish position="bottom-left" className="absolute bottom-0 left-0 w-20 sm:w-32 h-20 sm:h-32 text-[#D4AF37]/60" />
        <CornerFlourish position="bottom-right" className="absolute bottom-0 right-0 w-20 sm:w-32 h-20 sm:h-32 text-[#D4AF37]/60" />
      </div>

      {/* Radiant Golden Background Glow & Soft Heart Watermark */}
      <div className="absolute inset-0 flex items-center justify-center pointer-events-none opacity-30">
        <div className="w-[500px] h-[500px] rounded-full bg-gradient-to-tr from-[#FAD9C5] via-[#ECC880]/30 to-[#FDEEE4] blur-3xl animate-pulse" />
      </div>

      <div className="relative z-10 max-w-4xl mx-auto flex flex-col items-center text-center">
        {/* Lord Ganesha Invocation */}
        <motion.div
          initial={{ opacity: 0, y: -20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.8 }}
          className="flex flex-col items-center mb-4"
        >
          <GaneshaMotif className="w-16 h-16 sm:w-20 sm:h-20 drop-shadow-[0_4px_10px_rgba(212,175,55,0.35)]" />
          <p className="mt-2 font-cinzel text-xs sm:text-sm font-semibold tracking-[0.25em] text-[#8D5F13]">
            › SHREE GANESHAY NAMAH ‹
          </p>
        </motion.div>

        {/* Cordial Invitation Text */}
        <motion.div
          initial={{ opacity: 0, y: 15 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.8, delay: 0.15 }}
          className="space-y-1 mb-2"
        >
          <p className="font-cormorant italic text-base sm:text-xl text-[#732230] font-medium tracking-wide">
            You are cordially invited to celebrate the union of
          </p>
        </motion.div>

        {/* Grand Headline: AKSHITA & RAMIT */}
        <motion.div
          initial={{ opacity: 0, scale: 0.95 }}
          animate={{ opacity: 1, scale: 1 }}
          transition={{ duration: 0.9, delay: 0.3 }}
          className="my-3 sm:my-4"
        >
          <h1 className="font-cinzel text-3xl sm:text-5xl md:text-6xl font-extrabold text-[#5E1924] tracking-[0.08em] leading-tight">
            AKSHITA <span className="font-script text-4xl sm:text-6xl md:text-7xl font-normal text-[#C89938] mx-1 sm:mx-2">&</span> RAMIT
          </h1>
          <div className="flex items-center justify-center gap-3 mt-3">
            <div className="h-[1px] w-12 sm:w-24 bg-gradient-to-r from-transparent to-[#C89938]" />
            <span className="font-cinzel text-sm sm:text-lg font-bold tracking-[0.25em] text-gold-deep uppercase">
              The Ring Ceremony
            </span>
            <div className="h-[1px] w-12 sm:w-24 bg-gradient-to-l from-transparent to-[#C89938]" />
          </div>
        </motion.div>

        {/* Central Couple Visual & Animated Ring Exchange */}
        <motion.div
          initial={{ opacity: 0, y: 30 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 1, delay: 0.45 }}
          className="relative my-6 sm:my-8 flex flex-col items-center"
        >
          {/* Layered Romantic Heart Frame with Floral Accents */}
          <div className="relative w-72 sm:w-96 p-4 rounded-3xl bg-gradient-to-b from-[#FFF7F0] via-[#FFFDF9] to-[#FCEEE3] border border-[#ECC880]/50 shadow-[0_15px_35px_rgba(94,25,36,0.08)] flex flex-col items-center">
            
            {/* Top Interlocking Rings with Sparkle */}
            <div className="relative -mt-8 bg-[#FFFDF9] p-2 rounded-full border border-[#ECC880]/60 shadow-sm animate-float">
              <RoyalRings className="w-16 h-12" />
            </div>

            {/* Couple Illustration Container */}
            <div className="relative mt-2 w-full aspect-[4/3] rounded-2xl overflow-hidden bg-gradient-to-b from-[#FFF5EC] to-[#F9E6D5] flex items-center justify-center border border-[#ECC880]/30 shadow-inner group">
              
              {/* Couple Visual: Bride in Peach/Pink Lehenga, Groom in Ivory/Gold Sherwani */}
              <div className="relative w-full h-full flex items-center justify-center">
                {/* SVG Artistic Traditional Indian Wedding Couple Exchange */}
                <svg
                  viewBox="0 0 320 220"
                  className="w-full h-full max-h-56 object-contain"
                  fill="none"
                  xmlns="http://www.w3.org/2000/svg"
                  aria-label="Bride Akshita and Groom Ramit in traditional Indian ceremony attire"
                >
                  {/* Soft Warm Backdrop Arch */}
                  <path
                    d="M60 220 V110 C60 50 260 50 260 110 V220 Z"
                    fill="url(#archGlow)"
                    opacity="0.6"
                  />

                  {/* Groom (Right side - Ramit in Ivory & Golden Sherwani with Maroon Stole) */}
                  <g id="groom">
                    {/* Groom Sherwani Body */}
                    <path
                      d="M175 125 C175 110 190 100 205 100 C220 100 235 110 235 125 L230 215 L180 215 Z"
                      fill="#FFFDF7"
                      stroke="#ECC880"
                      strokeWidth="2"
                    />
                    {/* Golden Zari Embroidery on Collar and Placket */}
                    <path d="M205 102 L205 210" stroke="#C89938" strokeWidth="2.5" />
                    <circle cx="205" cy="120" r="1.5" fill="#8D5F13" />
                    <circle cx="205" cy="135" r="1.5" fill="#8D5F13" />
                    <circle cx="205" cy="150" r="1.5" fill="#8D5F13" />
                    <circle cx="205" cy="165" r="1.5" fill="#8D5F13" />
                    
                    {/* Royal Maroon Stole / Dupatta draped over shoulder */}
                    <path
                      d="M218 108 C226 120 228 150 226 190 C225 205 220 218 215 220"
                      stroke="#7A1D2A"
                      strokeWidth="9"
                      strokeLinecap="round"
                      fill="none"
                    />
                    <path
                      d="M218 108 C226 120 228 150 226 190 C225 205 220 218 215 220"
                      stroke="#D4AF37"
                      strokeWidth="1.5"
                      strokeDasharray="2 3"
                      fill="none"
                    />

                    {/* Groom Arm & Hand reaching out */}
                    <path
                      d="M190 125 Q168 140 156 142"
                      stroke="#FFFDF7"
                      strokeWidth="7"
                      strokeLinecap="round"
                    />
                    <circle cx="152" cy="142" r="3" fill="#ECC880" />

                    {/* Groom Head & Traditional Hair */}
                    <ellipse cx="205" cy="82" rx="10" ry="12" fill="#F8DAC3" />
                    <path d="M197 74 C198 68 206 66 214 70 C216 75 214 80 210 82 Z" fill="#2E1C14" />
                  </g>

                  {/* Bride (Left side - Akshita in Peach/Pink Lehenga, Kundan Jewelry & Flowing Dupatta) */}
                  <g id="bride">
                    {/* Flowing Dupatta / Veil */}
                    <path
                      d="M102 85 C90 100 85 140 88 200 C89 212 95 220 100 220"
                      stroke="#F472B6"
                      strokeWidth="7"
                      strokeLinecap="round"
                      opacity="0.85"
                      fill="none"
                    />
                    <path
                      d="M102 85 C90 100 85 140 88 200"
                      stroke="#ECC880"
                      strokeWidth="1.2"
                      strokeDasharray="2 3"
                      fill="none"
                    />

                    {/* Peach Lehenga Skirt */}
                    <path
                      d="M100 145 C105 145 125 145 130 145 L145 220 L85 220 Z"
                      fill="#FB7185"
                    />
                    {/* Golden Zardozi Borders */}
                    <path d="M85 212 L145 212" stroke="#FDE68A" strokeWidth="3" />
                    <path d="M88 217 L142 217" stroke="#D97706" strokeWidth="2" />

                    {/* Choli Blouse */}
                    <path
                      d="M102 118 C102 110 115 105 125 108 C132 112 132 125 132 140 L102 140 Z"
                      fill="#F43F5E"
                    />

                    {/* Bride Arm & Hand holding Groom's hand */}
                    <path
                      d="M125 125 Q140 138 152 142"
                      stroke="#F8DAC3"
                      strokeWidth="6"
                      strokeLinecap="round"
                    />
                    {/* Red Chooda / Bangles on Bride's wrist */}
                    <path d="M142 136 L147 140" stroke="#E11D48" strokeWidth="4" />
                    <path d="M143 135 L148 139" stroke="#ECC880" strokeWidth="1.5" />

                    {/* Bride Head, Maang Tikka & Jewelry */}
                    <ellipse cx="115" cy="85" rx="9" ry="11" fill="#F8DAC3" />
                    <path d="M108 78 C110 72 122 72 124 78 C124 82 120 86 116 87 Z" fill="#1F130E" />
                    {/* Golden Maang Tikka */}
                    <line x1="115" y1="74" x2="115" y2="80" stroke="#ECC880" strokeWidth="1.5" />
                    <circle cx="115" cy="81" r="1.5" fill="#B32638" />
                  </g>

                  {/* Interlocking Hands & Diamond Ring Glow */}
                  <g id="sparkle-ring">
                    <circle cx="154" cy="142" r="5" fill="#FFFFFF" opacity="0.9" />
                    <circle cx="154" cy="142" r="9" fill="#FDE68A" opacity="0.4" className="animate-ping" />
                    <line x1="154" y1="133" x2="154" y2="151" stroke="#F59E0B" strokeWidth="1.5" strokeLinecap="round" />
                    <line x1="145" y1="142" x2="163" y2="142" stroke="#F59E0B" strokeWidth="1.5" strokeLinecap="round" />
                  </g>

                  <defs>
                    <radialGradient id="archGlow" cx="0.5" cy="0.5" r="0.5">
                      <stop offset="0%" stopColor="#FEE2E2" />
                      <stop offset="70%" stopColor="#FEF3C7" />
                      <stop offset="100%" stopColor="#FFFBEB" />
                    </radialGradient>
                  </defs>
                </svg>

                {/* Subtle overlay button to view original uploaded invitation card */}
                <button
                  onClick={onOpenCardModal}
                  className="absolute bottom-2 right-2 px-2.5 py-1 rounded-full bg-[#3D0C13]/80 hover:bg-[#5E1924] text-[#ECC880] text-[10px] font-cinzel font-medium flex items-center gap-1 shadow-md transition-all cursor-pointer"
                >
                  <Sparkles className="w-3 h-3 text-[#ECC880]" />
                  <span>View Original Card</span>
                </button>
              </div>
            </div>

            <p className="mt-3 font-cormorant italic text-sm text-[#732230]">
              "Two souls bound by love, uniting in eternal promise"
            </p>
          </div>
        </motion.div>

        {/* Date, Time & Venue Key Strip */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.8, delay: 0.6 }}
          className="mt-2 flex flex-wrap items-center justify-center gap-4 sm:gap-8 text-xs sm:text-sm font-cinzel text-[#5E1924]"
        >
          <div className="flex items-center gap-2">
            <Calendar className="w-4 h-4 text-[#C89938]" />
            <span className="font-bold">23 NOVEMBER 2026</span>
            <span className="text-[#8D5F13]">·</span>
            <span>MONDAY</span>
          </div>

          <div className="hidden sm:inline text-[#C89938]">❖</div>

          <div className="flex items-center gap-2">
            <MapPin className="w-4 h-4 text-[#C89938]" />
            <span className="font-semibold">CHAUDHARY FARM HOUSE, MEERUT</span>
          </div>
        </motion.div>

        {/* Scroll Affordance Indicator */}
        <motion.div
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          transition={{ duration: 1, delay: 0.9 }}
          className="mt-8 flex flex-col items-center"
        >
          <a
            href="#couple"
            aria-label="Scroll to couple section"
            className="group flex flex-col items-center gap-1.5 text-xs font-cinzel tracking-widest text-[#8D5F13] hover:text-[#5E1924] transition-colors"
          >
            <span>DISCOVER THE CEREMONY</span>
            <div className="w-5 h-8 rounded-full border border-[#C89938]/60 p-1 flex justify-center">
              <div className="w-1.5 h-2 rounded-full bg-[#C89938] animate-bounce" />
            </div>
          </a>
        </motion.div>
      </div>
    </section>
  );
};
