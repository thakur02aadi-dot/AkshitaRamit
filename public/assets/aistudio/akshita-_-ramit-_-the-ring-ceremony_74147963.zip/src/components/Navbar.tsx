import React, { useState, useEffect } from 'react';
import { Volume2, VolumeX, Sparkles, Image as ImageIcon } from 'lucide-react';
import { weddingAudio } from '../utils/audioPlayer';

interface NavbarProps {
  onOpenCardModal: () => void;
  isMusicPlaying: boolean;
  setIsMusicPlaying: React.Dispatch<React.SetStateAction<boolean>>;
}

export const Navbar: React.FC<NavbarProps> = ({ onOpenCardModal, isMusicPlaying, setIsMusicPlaying }) => {
  const [isScrolled, setIsScrolled] = useState(false);

  useEffect(() => {
    const handleScroll = () => {
      setIsScrolled(window.scrollY > 20);
    };
    window.addEventListener('scroll', handleScroll, { passive: true });
    return () => window.removeEventListener('scroll', handleScroll);
  }, []);

  const handleToggleMusic = () => {
    const nowPlaying = weddingAudio.toggle();
    setIsMusicPlaying(nowPlaying);
  };

  return (
    <header
      className={`fixed top-0 inset-x-0 z-40 transition-all duration-300 ${
        isScrolled
          ? 'bg-[#FFFDF9]/95 backdrop-blur-md shadow-[0_4px_20px_rgba(94,25,36,0.08)] border-b border-[#ECC880]/40 py-2.5'
          : 'bg-[#FFFDF9]/80 backdrop-blur-sm border-b border-[#ECC880]/20 py-3.5'
      }`}
    >
      <div className="max-w-6xl mx-auto px-4 sm:px-6 flex items-center justify-between gap-6 md:gap-8">
        {/* Zone 1: Brand Wordmark (Single element, no extra tags) */}
        <a
          href="#hero"
          className="font-cinzel text-base sm:text-lg md:text-xl font-bold tracking-[0.15em] text-[#5E1924] hover:text-[#8D5F13] transition-colors whitespace-nowrap shrink-0 flex items-center gap-2"
        >
          <span className="text-gold-foil">AKSHITA & RAMIT</span>
        </a>

        {/* Zone 2: Single-line clean navigation links */}
        <nav className="hidden md:flex items-center gap-6 lg:gap-8 font-cinzel text-xs font-semibold tracking-wider text-[#732230]">
          <a href="#couple" className="hover:text-[#B38F24] transition-colors whitespace-nowrap shrink-0">
            THE COUPLE
          </a>
          <a href="#countdown" className="hover:text-[#B38F24] transition-colors whitespace-nowrap shrink-0">
            COUNTDOWN
          </a>
          <a href="#event" className="hover:text-[#B38F24] transition-colors whitespace-nowrap shrink-0">
            CEREMONY
          </a>
          <a href="#venue" className="hover:text-[#B38F24] transition-colors whitespace-nowrap shrink-0">
            VENUE
          </a>
          <a href="#rsvp" className="hover:text-[#B38F24] transition-colors whitespace-nowrap shrink-0">
            RSVP
          </a>
        </nav>

        {/* Zone 3: Primary Action & Audio Control */}
        <div className="flex items-center gap-2 sm:gap-3 shrink-0">
          {/* View Original Card Button */}
          <button
            onClick={onOpenCardModal}
            className="flex items-center gap-1.5 px-3 py-1.5 rounded-full border border-[#C89938]/50 bg-[#FDEEE4]/70 hover:bg-[#FAD9C5] text-[#5E1924] text-[11px] sm:text-xs font-cinzel font-semibold tracking-wider transition-all duration-200 shadow-sm cursor-pointer whitespace-nowrap shrink-0"
            title="View original invitation card image"
          >
            <ImageIcon className="w-3.5 h-3.5 text-[#8D5F13]" />
            <span className="hidden sm:inline">ORIGINAL CARD</span>
            <span className="sm:hidden">CARD</span>
          </button>

          {/* Sound / Music Toggle */}
          <button
            onClick={handleToggleMusic}
            aria-label={isMusicPlaying ? "Mute celebratory wedding music" : "Play celebratory wedding music"}
            className={`flex items-center gap-1.5 px-3 py-1.5 rounded-full text-xs font-cinzel font-semibold tracking-wider transition-all duration-200 cursor-pointer whitespace-nowrap shrink-0 shadow-sm ${
              isMusicPlaying
                ? 'bg-gradient-to-r from-[#D4AF37] to-[#B38F24] text-[#3D0C13] shadow-[0_2px_10px_rgba(212,175,55,0.4)]'
                : 'bg-white border border-[#ECC880] text-[#732230] hover:bg-[#FFF8E7]'
            }`}
          >
            {isMusicPlaying ? (
              <>
                <Volume2 className="w-3.5 h-3.5 animate-pulse" />
                <span className="hidden sm:inline">MUSIC ON</span>
              </>
            ) : (
              <>
                <VolumeX className="w-3.5 h-3.5" />
                <span className="hidden sm:inline">MUSIC OFF</span>
              </>
            )}
          </button>
        </div>
      </div>
    </header>
  );
};
