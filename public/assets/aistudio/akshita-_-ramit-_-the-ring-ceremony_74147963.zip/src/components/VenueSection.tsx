import React, { useState } from 'react';
import { motion } from 'motion/react';
import { FloralDivider, CornerFlourish } from './Ornaments';
import { MapPin, Navigation, Copy, Check, Car, Compass, PhoneCall } from 'lucide-react';

export const VenueSection: React.FC = () => {
  const [copied, setCopied] = useState(false);

  const venueTitle = "CHAUDHARY FARM HOUSE";
  const venueAddress = "Dilawra, Rohta Road, Meerut, Uttar Pradesh";
  const mapsSearchUrl = "https://www.google.com/maps/search/?api=1&query=Chaudhary+Farm+House%2C+Dilawra%2C+Rohta+Road%2C+Meerut";
  const mapsEmbedUrl = "https://maps.google.com/maps?q=Chaudhary+Farm+House,+Dilawra,+Rohta+Road,+Meerut&t=&z=14&ie=UTF8&iwloc=&output=embed";

  const handleCopyAddress = () => {
    navigator.clipboard.writeText(`${venueTitle}, ${venueAddress}`);
    setCopied(true);
    setTimeout(() => setCopied(false), 2500);
  };

  return (
    <section id="venue" className="relative py-20 px-4 sm:px-6 bg-gradient-to-b from-[#FFFDF9] via-[#FDF4EB] to-[#FFFDF9] overflow-hidden">
      <div className="relative z-10 max-w-5xl mx-auto flex flex-col items-center">
        {/* Section Heading */}
        <motion.div
          initial={{ opacity: 0, y: 15 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          transition={{ duration: 0.7 }}
          className="text-center"
        >
          <span className="font-cinzel text-xs sm:text-sm font-semibold tracking-[0.25em] text-[#8D5F13] uppercase">
            Location & Directions
          </span>
          <h2 className="mt-2 font-cinzel text-2xl sm:text-4xl md:text-5xl font-bold text-[#5E1924] tracking-wide">
            THE CELEBRATION DESTINATION
          </h2>
          <p className="mt-2 font-cormorant italic text-base sm:text-lg text-[#732230]">
            A grand open-air farmhouse setting in Meerut, ready to welcome you in royal style
          </p>
          <FloralDivider className="my-5" />
        </motion.div>

        {/* Venue Showcase Card */}
        <div className="w-full mt-8 grid grid-cols-1 lg:grid-cols-12 gap-8 items-stretch">
          
          {/* Left Info Panel */}
          <motion.div
            initial={{ opacity: 0, x: -30 }}
            whileInView={{ opacity: 1, x: 0 }}
            viewport={{ once: true }}
            transition={{ duration: 0.8 }}
            className="lg:col-span-5 relative p-6 sm:p-8 rounded-3xl bg-gradient-to-b from-[#FFFDF9] via-[#FFF8F1] to-[#FCEEE3] border border-[#ECC880]/70 shadow-[0_12px_32px_rgba(94,25,36,0.06)] flex flex-col justify-between"
          >
            <CornerFlourish position="top-left" className="absolute top-2 left-2 w-12 h-12 text-[#ECC880]/70" />
            
            <div>
              <div className="flex items-center gap-2 text-xs font-cinzel font-bold tracking-widest text-[#8D5F13]">
                <MapPin className="w-4 h-4 text-[#C89938]" />
                <span>VENUE OF CELEBRATION</span>
              </div>

              <h3 className="mt-3 font-cinzel text-2xl sm:text-3xl font-extrabold text-[#5E1924] leading-tight">
                {venueTitle}
              </h3>

              <div className="h-[2px] w-20 bg-gradient-to-r from-[#C89938] to-transparent my-4" />

              <p className="font-cinzel text-sm sm:text-base font-semibold text-[#3D0C13] leading-relaxed">
                DILAWRA, ROHTA ROAD, MEERUT
              </p>
              <p className="mt-1 text-xs font-sans-clean text-[#732230]/80">
                Uttar Pradesh, India
              </p>

              {/* Venue Highlights */}
              <div className="mt-6 space-y-3">
                <div className="flex items-start gap-3 p-3 rounded-xl bg-white/70 border border-[#ECC880]/40">
                  <Car className="w-4 h-4 text-[#8D5F13] shrink-0 mt-0.5" />
                  <div className="text-xs text-[#732230]/90">
                    <span className="font-bold text-[#5E1924]">Ample Guest Parking:</span> Dedicated parking inside the farmhouse premises for all cars and vehicles.
                  </div>
                </div>

                <div className="flex items-start gap-3 p-3 rounded-xl bg-white/70 border border-[#ECC880]/40">
                  <Compass className="w-4 h-4 text-[#8D5F13] shrink-0 mt-0.5" />
                  <div className="text-xs text-[#732230]/90">
                    <span className="font-bold text-[#5E1924]">Landmark Guidance:</span> Conveniently located on main Rohta Road near Dilawra, easily accessible from Meerut City & Bypass.
                  </div>
                </div>
              </div>
            </div>

            {/* Action Buttons */}
            <div className="mt-8 pt-6 border-t border-[#ECC880]/40 flex flex-col sm:flex-row gap-3">
              <a
                href={mapsSearchUrl}
                target="_blank"
                rel="noopener noreferrer"
                className="flex-1 py-3 px-4 rounded-xl bg-gradient-to-r from-[#D4AF37] to-[#B38F24] text-[#3D0C13] font-cinzel font-bold text-xs tracking-wider shadow-md hover:shadow-lg hover:scale-[1.02] active:scale-[0.98] transition-all flex items-center justify-center gap-2 cursor-pointer whitespace-nowrap"
              >
                <Navigation className="w-4 h-4 text-[#3D0C13]" />
                <span>GET DIRECTIONS</span>
              </a>

              <button
                onClick={handleCopyAddress}
                className="py-3 px-4 rounded-xl bg-white border border-[#ECC880] text-[#5E1924] hover:bg-[#FFF8E7] font-cinzel font-semibold text-xs tracking-wider transition-all flex items-center justify-center gap-2 cursor-pointer shadow-sm whitespace-nowrap"
              >
                {copied ? (
                  <>
                    <Check className="w-4 h-4 text-emerald-700" />
                    <span className="text-emerald-700">COPIED</span>
                  </>
                ) : (
                  <>
                    <Copy className="w-4 h-4 text-[#8D5F13]" />
                    <span>COPY ADDRESS</span>
                  </>
                )}
              </button>
            </div>
          </motion.div>

          {/* Right Interactive Map Frame */}
          <motion.div
            initial={{ opacity: 0, x: 30 }}
            whileInView={{ opacity: 1, x: 0 }}
            viewport={{ once: true }}
            transition={{ duration: 0.8 }}
            className="lg:col-span-7 relative rounded-3xl overflow-hidden border border-[#ECC880]/70 shadow-[0_12px_32px_rgba(94,25,36,0.08)] bg-[#FFFDF9] min-h-[360px] flex flex-col"
          >
            {/* Map Top Header */}
            <div className="px-5 py-3 bg-[#FFF9F3] border-b border-[#ECC880]/40 flex items-center justify-between">
              <div className="flex items-center gap-2 font-cinzel text-xs font-bold text-[#5E1924]">
                <MapPin className="w-4 h-4 text-[#C89938]" />
                <span>CHAUDHARY FARM HOUSE · LIVE MAP</span>
              </div>
              <a
                href={mapsSearchUrl}
                target="_blank"
                rel="noopener noreferrer"
                className="text-[11px] font-cinzel text-[#8D5F13] hover:underline flex items-center gap-1 font-semibold"
              >
                <span>Open in Google Maps</span>
                <span>↗</span>
              </a>
            </div>

            {/* Embedded Live Google Maps */}
            <div className="relative flex-1 w-full min-h-[320px]">
              <iframe
                title="Chaudhary Farm House Location Map"
                src={mapsEmbedUrl}
                width="100%"
                height="100%"
                style={{ border: 0 }}
                allowFullScreen={false}
                loading="lazy"
                referrerPolicy="no-referrer-when-downgrade"
                className="w-full h-full min-h-[320px] grayscale-[15%] contrast-[105%]"
              />
            </div>
          </motion.div>

        </div>
      </div>
    </section>
  );
};
