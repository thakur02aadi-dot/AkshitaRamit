/**
 * Royalty-free procedural Indian Wedding instrumental music synthesizer using Web Audio API.
 * Emulates a soothing traditional Shehnai/Bansuri flute melody over a warm Tanpura drone,
 * soft sitar strings, and gentle temple chimes.
 * 100% offline, zero external dependencies, no copyright risk, no 404s.
 */

class WeddingAudioPlayer {
  private ctx: AudioContext | null = null;
  private isPlaying: boolean = false;
  private isMuted: boolean = false;
  private masterGain: GainNode | null = null;
  private intervalId: number | null = null;
  private droneOscillators: OscillatorNode[] = [];

  // Raga Kalyan / Bilawal auspicious pentatonic scale frequencies (C#4 based)
  // Auspicious frequencies in Hz: Sa, Re, Ga, Pa, Dha, Sa'
  private scale = [
    277.18, // C#4 (Sa)
    311.13, // D#4 (Re)
    349.23, // F4  (Ga)
    415.30, // G#4 (Pa)
    466.16, // A#4 (Dha)
    554.37, // C#5 (High Sa)
    622.25, // D#5 (High Re)
    698.46, // F5  (High Ga)
  ];

  private melodyNotes = [
    0, 1, 2, 3, 2, 1, 0, 3, 4, 5, 4, 3, 2, 3, 5, 4, 3, 2, 1, 0, 4, 3, 0, 2, 1, 0
  ];
  private currentStep = 0;

  private initContext() {
    if (!this.ctx) {
      const AudioCtx = window.AudioContext || (window as unknown as { webkitAudioContext: typeof AudioContext }).webkitAudioContext;
      this.ctx = new AudioCtx();
      this.masterGain = this.ctx.createGain();
      this.masterGain.gain.setValueAtTime(0.35, this.ctx.currentTime);
      this.masterGain.connect(this.ctx.destination);
    }
    if (this.ctx.state === 'suspended') {
      this.ctx.resume();
    }
  }

  // Play a soft flute/shehnai tone with gentle vibrato and envelope
  private playFluteNote(freq: number, duration: number) {
    if (!this.ctx || !this.masterGain || this.isMuted) return;

    try {
      const now = this.ctx.currentTime;
      const osc = this.ctx.createOscillator();
      const gain = this.ctx.createGain();

      // Flute timbre using triangle wave
      osc.type = 'triangle';
      osc.frequency.setValueAtTime(freq, now);

      // Subtle vibrato (LFO)
      const lfo = this.ctx.createOscillator();
      const lfoGain = this.ctx.createGain();
      lfo.frequency.setValueAtTime(5.2, now); // 5.2 Hz vibrato
      lfoGain.gain.setValueAtTime(4.0, now);
      lfo.connect(osc.frequency);
      lfo.start(now);
      lfo.stop(now + duration);

      // Gentle attack and release envelope
      gain.gain.setValueAtTime(0.0001, now);
      gain.gain.exponentialRampToValueAtTime(0.22, now + 0.15);
      gain.gain.exponentialRampToValueAtTime(0.18, now + duration * 0.7);
      gain.gain.exponentialRampToValueAtTime(0.0001, now + duration);

      osc.connect(gain);
      gain.connect(this.masterGain);

      osc.start(now);
      osc.stop(now + duration + 0.05);
    } catch {
      // Audio playback safety
    }
  }

  // Gentle temple chime / bell sound
  private playBell(freq: number) {
    if (!this.ctx || !this.masterGain || this.isMuted) return;

    try {
      const now = this.ctx.currentTime;
      const osc = this.ctx.createOscillator();
      const gain = this.ctx.createGain();

      osc.type = 'sine';
      osc.frequency.setValueAtTime(freq * 2, now);

      gain.gain.setValueAtTime(0.0001, now);
      gain.gain.exponentialRampToValueAtTime(0.12, now + 0.02);
      gain.gain.exponentialRampToValueAtTime(0.0001, now + 1.8);

      osc.connect(gain);
      gain.connect(this.masterGain);

      osc.start(now);
      osc.stop(now + 1.9);
    } catch {
      // Audio context safe
    }
  }

  // Soft warm Tanpura drone background
  private startTanpuraDrone() {
    if (!this.ctx || !this.masterGain) return;
    this.stopDrone();

    const droneFreqs = [138.59, 207.65, 277.18]; // Low C#, G#, C#
    droneFreqs.forEach((f) => {
      if (!this.ctx || !this.masterGain) return;
      const osc = this.ctx.createOscillator();
      const gain = this.ctx.createGain();
      osc.type = 'sine';
      osc.frequency.setValueAtTime(f, this.ctx.currentTime);

      gain.gain.setValueAtTime(0.04, this.ctx.currentTime);
      osc.connect(gain);
      gain.connect(this.masterGain);
      osc.start();
      this.droneOscillators.push(osc);
    });
  }

  private stopDrone() {
    this.droneOscillators.forEach((osc) => {
      try {
        osc.stop();
        osc.disconnect();
      } catch {
        // Safe disconnect
      }
    });
    this.droneOscillators = [];
  }

  public play() {
    this.initContext();
    if (this.isPlaying) return;

    this.isPlaying = true;
    this.startTanpuraDrone();

    // Play initial chime
    this.playBell(554.37);

    // Sequence the melodic notes
    this.intervalId = window.setInterval(() => {
      if (!this.isPlaying) return;
      const noteIdx = this.melodyNotes[this.currentStep % this.melodyNotes.length];
      const freq = this.scale[noteIdx % this.scale.length];
      
      this.playFluteNote(freq, 1.1);

      // Add occasional gentle temple bell on key beats
      if (this.currentStep % 8 === 0) {
        this.playBell(554.37);
      } else if (this.currentStep % 8 === 4) {
        this.playBell(415.30);
      }

      this.currentStep++;
    }, 1200);
  }

  public pause() {
    this.isPlaying = false;
    this.stopDrone();
    if (this.intervalId) {
      clearInterval(this.intervalId);
      this.intervalId = null;
    }
  }

  public toggle(): boolean {
    if (this.isPlaying) {
      this.pause();
      return false;
    } else {
      this.play();
      return true;
    }
  }

  public getIsPlaying(): boolean {
    return this.isPlaying;
  }
}

export const weddingAudio = new WeddingAudioPlayer();
